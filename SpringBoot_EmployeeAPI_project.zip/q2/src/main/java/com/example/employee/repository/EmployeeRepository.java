package com.example.employee.repository;

import com.example.employee.model.Employee;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
public class EmployeeRepository {

    private final JdbcTemplate jdbc;

    public EmployeeRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private final RowMapper<Employee> mapper = (rs, i) -> new Employee(
            rs.getInt("id"), rs.getString("name"),
            rs.getString("department"), rs.getDouble("salary"));

    public Employee save(Employee e) {
        KeyHolder keys = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO employee (name, department, salary) VALUES (?,?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, e.getName());
            ps.setString(2, e.getDepartment());
            ps.setDouble(3, e.getSalary());
            return ps;
        }, keys);
        e.setId(keys.getKey().intValue());
        return e;
    }

    public List<Employee> findAll() {
        return jdbc.query("SELECT * FROM employee", mapper);
    }

    public Optional<Employee> findById(int id) {
        try {
            return Optional.ofNullable(
                    jdbc.queryForObject("SELECT * FROM employee WHERE id = ?", mapper, id));
        } catch (EmptyResultDataAccessException ex) {
            return Optional.empty();
        }
    }

    public boolean update(int id, Employee e) {
        return jdbc.update("UPDATE employee SET name=?, department=?, salary=? WHERE id=?",
                e.getName(), e.getDepartment(), e.getSalary(), id) > 0;
    }

    public boolean delete(int id) {
        return jdbc.update("DELETE FROM employee WHERE id = ?", id) > 0;
    }
}
