package com.kiet.student.controller;

import com.kiet.student.model.Student;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/students")
public class StudentController {

    // In-memory storage (no database)
    private final List<Student> students = new ArrayList<>();

    public StudentController() {
        students.add(new Student(101, "Rahul Sharma", "rahul@kiet.edu", "CSE(AI & ML)", 2, 8.65));
        students.add(new Student(102, "Priya Singh", "priya@kiet.edu", "CSE", 2, 9.20));
        students.add(new Student(103, "Ankit Verma", "ankit@kiet.edu", "IT", 3, 7.85));
        students.add(new Student(104, "Neha Gupta", "neha@kiet.edu", "CSE", 3, 9.45));
        students.add(new Student(105, "Vikas Yadav", "vikas@kiet.edu", "ECE", 1, 8.10));
    }

    private Optional<Student> findById(int id) {
        return students.stream().filter(s -> s.getStudentId() == id).findFirst();
    }

    private ResponseEntity<Map<String, String>> notFound() {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "Student not found"));
    }

    // ---------- Question 3 : GET APIs ----------

    // GET /students
    @GetMapping
    public List<Student> getAllStudents() {
        return students;
    }

    // GET /students/{studentId}
    @GetMapping("/{studentId}")
    public ResponseEntity<?> getStudentById(@PathVariable int studentId) {
        Optional<Student> student = findById(studentId);
        if (student.isPresent()) {
            return ResponseEntity.ok(student.get());
        }
        return notFound();
    }

    // ---------- Question 4 : POST API ----------

    // POST /students
    @PostMapping
    public ResponseEntity<?> addStudent(@RequestBody Student student) {
        if (findById(student.getStudentId()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("message", "Student with this ID already exists"));
        }
        students.add(student);
        return ResponseEntity.status(HttpStatus.CREATED).body(student);
    }

    // ---------- Question 5 : PUT & DELETE APIs ----------

    // PUT /students/{studentId}
    @PutMapping("/{studentId}")
    public ResponseEntity<?> updateStudent(@PathVariable int studentId, @RequestBody Student updated) {
        Optional<Student> existing = findById(studentId);
        if (existing.isEmpty()) {
            return notFound();
        }
        Student s = existing.get();
        s.setName(updated.getName());
        s.setEmail(updated.getEmail());
        s.setBranch(updated.getBranch());
        s.setYear(updated.getYear());
        s.setCgpa(updated.getCgpa());
        return ResponseEntity.ok(s);
    }

    // DELETE /students/{studentId}
    @DeleteMapping("/{studentId}")
    public ResponseEntity<Map<String, String>> deleteStudent(@PathVariable int studentId) {
        Optional<Student> existing = findById(studentId);
        if (existing.isEmpty()) {
            return notFound();
        }
        students.remove(existing.get());
        return ResponseEntity.ok(Map.of("message", "Student deleted successfully"));
    }

    // ---------- Question 6 : @RequestParam APIs ----------

    // GET /students/search?branch=CSE&year=2
    // Branch match is case-insensitive and partial, so "CSE" also matches "CSE(AI & ML)".
    @GetMapping("/search")
    public List<Student> searchByBranchAndYear(@RequestParam String branch, @RequestParam int year) {
        return students.stream()
                .filter(s -> s.getBranch().toLowerCase().contains(branch.toLowerCase()))
                .filter(s -> s.getYear() == year)
                .toList();
    }

    // GET /students/topper?cgpa=9.0
    @GetMapping("/topper")
    public List<Student> findByCgpa(@RequestParam double cgpa) {
        return students.stream()
                .filter(s -> s.getCgpa() >= cgpa)
                .toList();
    }
}
