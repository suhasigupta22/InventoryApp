# KIET Student Management REST API

Run: `mvn spring-boot:run`  (Java 17+, port 8080)

## curl tests (for your screenshots)
```
curl localhost:8080/students
curl localhost:8080/students/101
curl localhost:8080/students/999
curl -X POST localhost:8080/students -H "Content-Type: application/json" -d '{"studentId":106,"name":"Amit Kumar","email":"amit@kiet.edu","branch":"CSE(AI)","year":2,"cgpa":8.75}'
curl -X PUT localhost:8080/students/101 -H "Content-Type: application/json" -d '{"studentId":101,"name":"Rahul Sharma","email":"rahul@kiet.edu","branch":"CSE(AI & ML)","year":3,"cgpa":9.05}'
curl -X DELETE localhost:8080/students/105
curl "localhost:8080/students/search?branch=CSE&year=2"
curl "localhost:8080/students/topper?cgpa=9.0"
```
